module.exports = {
  devIndicators: {
    autoPrerender: false,
  },
};
