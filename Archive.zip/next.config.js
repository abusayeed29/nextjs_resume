module.exports = {
  images: {
    domains: ['sayeedinfo.com'],
  },
  devIndicators: {
    autoPrerender: false,
  },
};
