module.exports = {
  images: {
    domains: ['api.sayeedinfo.com'],
  },
  devIndicators: {
    autoPrerender: false,
  },
};
