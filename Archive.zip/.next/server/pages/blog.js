"use strict";
(() => {
var exports = {};
exports.id = 195;
exports.ids = [195];
exports.modules = {

/***/ 7538:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages_blog),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(701);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2376);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
// EXTERNAL MODULE: ./components/Header.js + 1 modules
var Header = __webpack_require__(953);
// EXTERNAL MODULE: ./components/Footer.js
var Footer = __webpack_require__(2651);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/PostCard.js





const PostCard = ({
  title,
  slug,
  body,
  tags
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "max-w-3xl mx-4 mb-10 rounded-lg shadow-sm",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "bg-gray-50 p-8",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "text-xs text-gray-600 uppercase font-semibold",
          children: "23 Sep 2020"
        }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
          className: "text-2xl font-bold leading-8 tracking-tight",
          children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: `/blog/${slug}`,
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              className: "text-gray-900 dark:text-gray-100",
              children: title
            })
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "leading-normal text-gray-700",
          children: body
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "flex space-x-2 mt-5",
          children: tags && tags.map((tag, i) => {
            return /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "text-xs px-3 bg-gray-200 text-gray-800 rounded-full",
              children: tag.tag.name
            }, i);
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: `/blog/${slug}`,
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
            className: "flex items-center mt-6 uppercase text-sm text-black font-semibold",
            children: ["Read article ", /*#__PURE__*/jsx_runtime_.jsx("svg", {
              className: "w-4 h-4 ml-2",
              fill: "none",
              stroke: "currentColor",
              viewBox: "0 0 24 24",
              xmlns: "http://www.w3.org/2000/svg",
              children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                "stroke-linecap": "round",
                "stroke-linejoin": "round",
                "stroke-width": "1",
                d: "M9 5l7 7-7 7"
              })
            })]
          })
        })]
      })
    })
  });
};

/* harmony default export */ const components_PostCard = (PostCard);
;// CONCATENATED MODULE: ./pages/blog.js








const blog = ({
  posts
}) => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)((head_default()), {
      children: [/*#__PURE__*/jsx_runtime_.jsx("title", {
        children: "Sayeedinfo.com | Blog"
      }), /*#__PURE__*/jsx_runtime_.jsx("link", {
        rel: "icon",
        href: "/favicon.ico"
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(Header/* default */.Z, {}), /*#__PURE__*/(0,jsx_runtime_.jsxs)("main", {
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("section", {
        className: "text-center bg-gradient-to-r from-gray-200 to-gray-300 py-20",
        children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
          className: "mb-2 text-2xl font-bold text-gray-700 lg:text-4xl mt-10 ",
          children: "Blog "
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "text-white",
          children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
            className: "text-blue-800",
            children: "Home -"
          }), " Blog"]
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("section", {
        className: "container mx-auto px-6 gap-12 pt-12 pb-24 py-20",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "grid grid-cols-1 lg:grid-cols-12 gap-12",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "lg:col-span-8 col-span-1",
            children: posts && posts.map((post, index) => /*#__PURE__*/jsx_runtime_.jsx(components_PostCard, {
              title: post.title,
              slug: post.slug,
              body: post.body,
              tags: post.post_has_tags
            }, index))
          }), /*#__PURE__*/jsx_runtime_.jsx("aside", {
            className: "lg:col-span-4 col-span-1",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "lg:sticky relative top-8",
              children: [/*#__PURE__*/jsx_runtime_.jsx("h2", {
                className: "sr-only",
                children: "Details"
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "space-y-5",
                children: /*#__PURE__*/jsx_runtime_.jsx("div", {
                  className: "flex items-center space-x-2",
                  children: /*#__PURE__*/jsx_runtime_.jsx("span", {
                    className: "font-display text-4xl font-extrabold text-cool-indigo-600",
                    children: "Category"
                  })
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "mt-6 border-t border-gray-200 pt-6 space-y-5",
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
                  className: "space-y-4",
                  children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
                    className: "flex items-start lg:col-span-1",
                    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
                      className: "flex-shrink-0",
                      children: /*#__PURE__*/jsx_runtime_.jsx("svg", {
                        className: "h-5 w-5 text-teal-400",
                        "x-description": "Heroicon name: check-circle",
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 20 20",
                        fill: "currentColor",
                        "aria-hidden": "true",
                        children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                          "fill-rule": "evenodd",
                          d: "M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z",
                          "clip-rule": "evenodd"
                        })
                      })
                    }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                      className: "ml-3 text-base text-teal-700 font-medium",
                      children: "Well documented"
                    })]
                  }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
                    className: "flex items-start lg:col-span-1",
                    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
                      className: "flex-shrink-0",
                      children: /*#__PURE__*/jsx_runtime_.jsx("svg", {
                        className: "h-5 w-5 text-teal-400",
                        "x-description": "Heroicon name: check-circle",
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 20 20",
                        fill: "currentColor",
                        "aria-hidden": "true",
                        children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                          "fill-rule": "evenodd",
                          d: "M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z",
                          "clip-rule": "evenodd"
                        })
                      })
                    }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                      className: "ml-3 text-base text-teal-700 font-medium",
                      children: "Well documented"
                    })]
                  })]
                })
              })]
            })
          })]
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(Footer/* default */.Z, {})]
    })]
  });
};

/* harmony default export */ const pages_blog = (blog); // Fetch data at build time

async function getStaticProps(context) {
  const response = await external_axios_default().get(`http://api.sayeedinfo.com/api/posts`);
  const posts = response.data;
  return {
    props: {
      posts: posts
    }
  };
}

/***/ }),

/***/ 2953:
/***/ ((module) => {

module.exports = require("@fortawesome/free-brands-svg-icons");

/***/ }),

/***/ 887:
/***/ ((module) => {

module.exports = require("@fortawesome/free-solid-svg-icons");

/***/ }),

/***/ 799:
/***/ ((module) => {

module.exports = require("@fortawesome/react-fontawesome");

/***/ }),

/***/ 2376:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 9325:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 701:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6731:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 9297:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 3783:
/***/ ((module) => {

module.exports = require("react-scroll");

/***/ }),

/***/ 5282:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [664,916,651], () => (__webpack_exec__(7538)));
module.exports = __webpack_exports__;

})();