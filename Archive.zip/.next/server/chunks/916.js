exports.id = 916;
exports.ids = [916];
exports.modules = {

/***/ 953:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_Header)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react-scroll"
var external_react_scroll_ = __webpack_require__(3783);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/sections/NavBar.js







const NavBar = () => {
  const router = (0,router_.useRouter)(); //console.log(router.asPath);

  const {
    0: mounted,
    1: setMounted
  } = (0,external_react_.useState)(false);
  const {
    0: active,
    1: setActive
  } = (0,external_react_.useState)(false);

  const handleClick = () => {
    setActive(!active);
  };

  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "container mx-auto",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("nav", {
      className: "flex items-center flex-wrap p-3",
      children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
        href: "/",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
          className: "inline-flex items-center p-2 mr-4 ",
          children: [/*#__PURE__*/jsx_runtime_.jsx("svg", {
            viewBox: "0 0 24 24",
            xmlns: "http://www.w3.org/2000/svg",
            className: "fill-current text-white h-8 w-8 mr-2",
            children: /*#__PURE__*/jsx_runtime_.jsx("path", {
              d: "M12.001 4.8c-3.2 0-5.2 1.6-6 4.8 1.2-1.6 2.6-2.2 4.2-1.8.913.228 1.565.89 2.288 1.624C13.666 10.618 15.027 12 18.001 12c3.2 0 5.2-1.6 6-4.8-1.2 1.6-2.6 2.2-4.2 1.8-.913-.228-1.565-.89-2.288-1.624C16.337 6.182 14.976 4.8 12.001 4.8zm-6 7.2c-3.2 0-5.2 1.6-6 4.8 1.2-1.6 2.6-2.2 4.2-1.8.913.228 1.565.89 2.288 1.624 1.177 1.194 2.538 2.576 5.512 2.576 3.2 0 5.2-1.6 6-4.8-1.2 1.6-2.6 2.2-4.2 1.8-.913-.228-1.565-.89-2.288-1.624C10.337 13.382 8.976 12 6.001 12z"
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("span", {
            className: "text-xl text-white font-bold uppercase tracking-wide",
            children: "Abu Sayeed"
          })]
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("button", {
        className: "inline-flex p-3 hover:bg-gray-600 rounded lg:hidden text-white ml-auto hover:text-white outline-none",
        onClick: handleClick,
        children: /*#__PURE__*/jsx_runtime_.jsx("svg", {
          className: "w-6 h-6",
          fill: "none",
          stroke: "currentColor",
          viewBox: "0 0 24 24",
          xmlns: "http://www.w3.org/2000/svg",
          children: /*#__PURE__*/jsx_runtime_.jsx("path", {
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: 2,
            d: "M4 6h16M4 12h16M4 18h16"
          })
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: `${active ? '' : 'hidden'}   w-full lg:inline-flex lg:flex-grow lg:w-auto`,
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "lg:inline-flex lg:flex-row lg:ml-auto lg:w-auto w-full lg:items-center items-start  flex flex-col lg:h-auto",
          children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "/",
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              className: `lg:inline-flex lg:w-auto w-full px-3 py-2 rounded text-white font-bold items-center justify-center hover:bg-gray-600 hover:text-white ${router.asPath === "/" ? "text-red-500 dark:text-gray-400" : "text-white"}`,
              children: "About Me"
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "/resume",
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              className: `lg:inline-flex lg:w-auto w-full px-3 py-2 rounded text-white font-bold items-center justify-center hover:bg-gray-600 hover:text-white ${router.asPath === "/resume" ? "text-red-500 dark:text-gray-400" : "text-white"}`,
              children: "Resume"
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "/portfolio",
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              className: `lg:inline-flex lg:w-auto w-full px-3 py-2 rounded text-white font-bold items-center justify-center hover:bg-gray-600 hover:text-white ${router.asPath === "/portfolio" ? "text-red-500 dark:text-gray-400" : "text-white"}`,
              children: "Portfolio"
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "/blog",
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              className: `lg:inline-flex lg:w-auto w-full px-3 py-2 rounded text-white font-bold items-center justify-center hover:bg-gray-600 hover:text-white ${router.asPath === "/blog" ? "text-red-500 dark:text-gray-400" : "text-white"}`,
              children: "Blog"
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "/contact",
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              className: `lg:inline-flex lg:w-auto w-full px-3 py-2 rounded text-white font-bold items-center justify-center hover:bg-gray-600 hover:text-white ${router.asPath === "/contact" ? "text-red-500 dark:text-gray-400" : "text-white"}`,
              children: "Contact"
            })
          })]
        })
      })]
    })
  });
};

/* harmony default export */ const sections_NavBar = (NavBar);
;// CONCATENATED MODULE: ./components/Header.js




const Header = ({
  data
}) => {
  if (data) {
    var name = data.name;
    var occupation = data.occupation;
    var description = data.description;
    var city = data.address.city;
    var networks = data.social.map(function (network) {
      return /*#__PURE__*/jsx_runtime_.jsx("li", {
        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
          href: network.url,
          children: /*#__PURE__*/jsx_runtime_.jsx("i", {
            className: network.className
          })
        })
      }, network.name);
    });
  }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("header", {
    style: {
      background: '#091C29'
    },
    className: "font-dosis fixed top-0 w-screen z-40",
    children: [/*#__PURE__*/jsx_runtime_.jsx(sections_NavBar, {}), /*#__PURE__*/jsx_runtime_.jsx("p", {
      className: "scrolldown",
      children: /*#__PURE__*/jsx_runtime_.jsx("a", {
        className: "smoothscroll",
        href: "#about",
        children: /*#__PURE__*/jsx_runtime_.jsx("i", {
          className: "icon-down-circle"
        })
      })
    })]
  });
};

/* harmony default export */ const components_Header = (Header);

/***/ }),

/***/ 2431:
/***/ (() => {

/* (ignored) */

/***/ })

};
;